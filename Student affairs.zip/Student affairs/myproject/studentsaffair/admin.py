from django.contrib import admin

from studentsaffair.models import Student

# Register your models here.
admin.site.register(Student)
